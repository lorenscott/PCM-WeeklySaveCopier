# PCM-WeeklySaveCopier
Pro Cycling Manager 2023 Weekly Saved File Copier

When needing to restore from a weekly save within Pro Cycling Manager 2023, 
it can be diffuclt to remember where the backup files are stored, and where 
the desired backup needs to be copied to. This utility makes that easier.

NOTES: 

1. Currently is defaulted to my (Loren Scott's) own source/destination folders.
   
2. Next enhancement would be to dynamically detect and set those values.
